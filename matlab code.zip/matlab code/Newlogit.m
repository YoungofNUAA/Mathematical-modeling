%���������ȼ� �÷���������
maxMoney = max(data6);
minMoney = min(data6);
level = fix((maxMoney-minMoney)/2);
uplevel_index = find(data6>=level);
belowlevel_index = find(data6<level);
% wNew_uplevel = 0.5*sum(data6(uplevel_index))./length(uplevel_index)*12/(50*40);
% wNew_belowlevel = 0.5*sum(data6(belowlevel_index))./length(belowlevel_index)*12/(50*40);

%�г����Ա���---ʱ��
Time_gaotie = sum(data4(gaotie_index))/length(gaotie_index)*14.58;
% Time_gaotie_belowlevel = sum(data4(gaotie_index))/length(gaotie_index)*wNew_belowlevel;
Time_pukuai = sum(data4(pukuai_index))/length(pukuai_index)*14.58;
% Time_pukuai_belowlevel = sum(data4(pukuai_index))/length(pukuai_index)*wNew_belowlevel;

%����
Money_gaotie = sum(data8(gaotie_index))/length(gaotie_index);
Money_pukuai = sum(data8(pukuai_index))/length(pukuai_index);

%���ʶ�
isComfort_gaotie = 1;
isComfort_pukuai = 0.7;

belt_Time_uplevel = 0.12;
belt_Money_uplevel = 0.47;
belt_isComfort_uplevel = 1.00;

belt_Time_belowlevel = 0.22;
belt_Money_belowlevel = 0.31;
belt_isComfort_belowlevel = 2.30;

% ���
x1 = data8;
x2 = data4;
y = data3;
x=[ones(160,1),x1,x2];
b = regress(y,x);
scatter3(x1,x2,y,'filled');