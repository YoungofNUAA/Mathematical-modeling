%��֧�����뻮�ֵȼ�
Index_10000 = find(data6==10000);
data6(Index_10000) = [];
MaxMoney = max(data6);
MinMoney = min(data6);
level1 = fix(MaxMoney - (MaxMoney-MinMoney)/3);
level2 = fix(MaxMoney - 2*(MaxMoney-MinMoney)/3);
level3 = MinMoney;
level1_gaotie = length(find(data6(gaotie_index)>=level1));
level1_pukuai = length(find(data6(pukuai_index)>=level1));
level2_gaotie = length(find((data6(gaotie_index)>=level2)&(data6(gaotie_index)<level1)));
level2_pukuai = length(find((data6(pukuai_index)>=level2)&(data6(pukuai_index)<level1)));
level3_gaotie = length(find((data6(gaotie_index)>=level3)&(data6(gaotie_index)<level2)));
level3_pukuai = length(find((data6(pukuai_index)>=level3)&(data6(pukuai_index)<level2)));
figure;
plotdata = [level1_gaotie level1_pukuai;level2_gaotie level2_pukuai;level3_gaotie level3_pukuai];
b = bar(plotdata);
ch = get(b,'children');
set(gca,'XTickLabel',{'�ȼ�һ','�ȼ���','�ȼ���'});  

%����ʱ���ֵ
Year_money = data6.*12;
w = 0.5.*Year_money./(50*40);
%���ʶ�����
% test = 0:1:30;
gt_gaotie = 15./(1+39.*exp(-0.4.*data4(gaotie_index)));
gt_pukuai = 15./(1+59.*exp(-0.28.*data4(pukuai_index)));
% figure
% plot(gt_gaotie);
% hold on;
% plot(gt_pukuai);
Gt_gaotie = gt_gaotie.*w(gaotie_index);
Gt_pukuai = gt_pukuai.*w(pukuai_index);
Gt_mean_gaotie = mean(Gt_gaotie);
Gt_mean_pukuai = mean(Gt_pukuai);

% figure
% plot(Gt_gaotie);
% hold on;
% plot(Gt_pukuai);


