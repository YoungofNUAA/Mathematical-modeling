filename1 = '���������ø�У��������һ��س���Ϣ�����.xlsx';
sheet = 1;
xlRange = ['A20:A180';'B20:B180';'C20:C180';'D20:D180';'E20:E180';'F20:F180';....
    'G20:G180';'H20:H180';'I20:I180';'J20:J180';'K20:K180'];

[num1,txt1,raw1] = xlsread(filename1,sheet,'A20:A180');
pre_stuNo = txt1;
pre_data2 = xlsread(filename1,sheet,'C20:C180');
pre_data3 = [];
pre_data4 = xlsread(filename1,sheet,'E20:E180');
pre_data5 = xlsread(filename1,sheet,'F20:F180');
pre_data6 = xlsread(filename1,sheet,'G20:G180');
pre_data7 = xlsread(filename1,sheet,'H20:H180');
pre_data8 = xlsread(filename1,sheet,'I20:I180');
pre_data9 = xlsread(filename1,sheet,'J20:J180');
pre_data10 = xlsread(filename1,sheet,'K20:K180');
pre_w = 0.5.*12*pre_data6./(50*40);
U_gaotie = 0.25.*pre_data4+0.75.*pre_data8+0.8.*(15./(1+39.*exp(-0.4.*pre_data4)));
U_pukuai = 0.75.*pre_data4+0.25.*pre_data8+0.2.*(15./(1+59.*exp(-0.28.*pre_data4)));
Probility = (U_gaotie./sum(U_gaotie))./((U_gaotie./sum(U_gaotie))+(U_pukuai./sum(U_pukuai)));
Pro_index_up05 = find(Probility>=0.5);
Pro_index_below05 = find(Probility<0.5);

%Ԥ������д��excel
% filename2 = '������Ԥ������';
% write_gaotie_stuNo = pre_stuNo(Pro_index_up05);
% write_pukuai_stuNo = pre_stuNo(Pro_index_below05);
% xlswrite(filename2,pre_stuNo,'A1');
% write_data = zeros(85,1);
% write_data(Pro_index_up05) = 1;
% xlswrite(filename2,write_data,'B1');

Correct_gaotie = length(intersect(Pro_index_up05,gaotie_index));
Correct_pukuai = length(intersect(Pro_index_below05,pukuai_index));
correct_ratio_gaotie = Correct_gaotie/length(Pro_index_up05);
correct_ratio_pukuai = Correct_pukuai/length(Pro_index_below05);
correct_total = (Correct_gaotie+Correct_pukuai)/(length(gaotie_index)+length(pukuai_index));

figure
plot(U_gaotie./sum(U_gaotie),U_pukuai./sum(U_pukuai),'b.');
hold on
plot(0:0.0001:0.017,0:0.0001:0.017,'r');
xlabel('��һ����ĸ���Ч��');
ylabel('��һ������տ�Ч��');

%ʵ�ʺ�Ԥ������ֱ����ʾ
figure
num_index = 1:160;
plot(gaotie_index,1,'r*');
hold on
plot(Pro_index_up05,1,'bo');
xlabel('ѧ�����')
ylabel('1����ѡ���������')

figure
num_index = 1:160;
plot(pukuai_index,0,'r*');
hold on
plot(Pro_index_below05,0,'bo');
ylim([-1,1])
xlabel('ѧ�����')
ylabel('0����ѡ��𳵳���')
%�Ľ�
% V_gaotie = 0.25.*pre_w.*pre_data4.*pre_data10+0.75.*pre_data8.*pre_data7+0.8.*(15./(1+39.*exp(-0.4.*pre_data4))).*pre_w.*pre_data9+0.8.*pre_data6;
% V_pukuai = 0.75.*pre_w.*pre_data4.*pre_data10+0.25.*pre_data8.*pre_data7+0.2.*(15./(1+39.*exp(-0.4.*pre_data4))).*pre_w.*pre_data9+0.2.*pre_data6;
% V_Probility = V_gaotie./(V_gaotie+V_pukuai);
